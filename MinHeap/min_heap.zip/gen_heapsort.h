#ifndef GEN_HEAPSORT_H
#define GEN_HEAPSORT_H

void HeapSortGen(void** data, int num_elems, int (*Compare)(void*, void*));

#endif //GEN_HEAPSORT_H
