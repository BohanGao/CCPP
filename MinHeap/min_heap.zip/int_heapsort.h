//
// Created by Bohan Gao on 7/31/20.
//

#ifndef INT_HEAPSORT_H
#define INT_HEAPSORT_H

void HeapSortInt(int *data, int num_elems);

#endif //INT_HEAPSORT_H